package trab_RBT;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class MarcioBST {

	public static void main(String[] args) {
		RedBlackBST<String, Integer> st = new RedBlackBST<String, Integer>();
		String delims = "[=]+";
		String[] inputs = null;
		String chave = null;
		String valor = null;

		Scanner lerDado = new Scanner(System.in);
		String dadoLido = "";
		String funcaoLida = "";

		

		while (!funcaoLida.contains("SAIR")) {
			System.out
					.println("Digite a a��o: <ARQUIVO> <INSERIR> <CONSULTAR> <EXCLUIR> <SAIR>");
			funcaoLida = lerDado.nextLine();

			if (funcaoLida.contains("INSERIR")) {
				System.out.println("Digite uma chave para INSERIR:");
				chave = lerDado.nextLine();
				System.out.println("Digite um valor para INSERIR:");
				valor = lerDado.nextLine();
//				st.put(chave, Integer.parseInt(valor));
				st.put(chave, Integer.parseInt(valor));
			} else if (funcaoLida.contains("CONSULTAR")) {
				System.out.println("Digite uma chave para CONSULTAR:");
				dadoLido = lerDado.nextLine();
				System.out.println(st.get(dadoLido));
			} else if (funcaoLida.contains("EXCLUIR")) {
				System.out.println("Digite uma chave para DELETAR:");
				dadoLido = lerDado.nextLine();
				st.delete(dadoLido);
			} else if (funcaoLida.contains("ARQUIVO")) {
				System.out.println("Digite o caminho do arquivo:");
				dadoLido = lerDado.nextLine();
				try {
					BufferedReader in = new BufferedReader(new FileReader(
							dadoLido));
					String str;
					while (in.ready()) {
						str = in.readLine();
						inputs = str.split(delims);
						chave = inputs[0];
						valor = inputs[1];
						st.put(chave, Integer.parseInt(valor));
					}
					in.close();
				} catch (IOException e) {
				}
			} else {
			        System.out.println("Comando errado.");
		}
	}
}
